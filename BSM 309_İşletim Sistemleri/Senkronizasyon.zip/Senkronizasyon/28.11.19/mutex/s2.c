#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
void *functionB();
void *functionC();
void *functionD();
pthread_mutex_t mutex1 = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t count_mutex     = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t condition_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t condition_mutex2 = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t  condition_cond  = PTHREAD_COND_INITIALIZER;
pthread_cond_t  condition_cond2  = PTHREAD_COND_INITIALIZER;
int  counter = 1;
int rasg;
int yt;

main()
{
   
   int rc0,rc1, rc2;
   pthread_t thread0,thread1, thread2;

   /* Create independent threads each of which will execute functionC */ 
   if( (rc0=pthread_create( &thread0, NULL, &functionB, NULL)) )
   {
      printf("Thread creation failed: %d\n", rc0);
   } 
	

   if( (rc1=pthread_create( &thread1, NULL, &functionC, NULL)) )
   {
      printf("Thread creation failed: %d\n", rc1);
   }

  /* if( (rc2=pthread_create( &thread2, NULL, &functionD, NULL)) )
   {
      printf("Thread creation failed: %d\n", rc2);
   }
*/

   /* Wait till threads are complete before main continues. Unless we  */
   /* wait we run the risk of executing an exit which will terminate   */
   /* the process and all threads before the threads have completed.   */
   pthread_join( thread0, NULL);
   pthread_join( thread1, NULL);
    

   exit(0);
}
void *functionB() //atomik fonksiyon
{
  for(;;){
    
   
     pthread_mutex_lock( &condition_mutex );
       if( counter%5==0 )
       {
       
        pthread_cond_signal( &condition_cond );		

        pthread_mutex_unlock( &condition_mutex );
      //break;         
       }
else{ 
 
printf("sayı=%d \n",counter);
counter++;
	sleep(1);
       pthread_mutex_unlock( &condition_mutex ); 

}
}
}

void *functionC()  //atomik fonk.
{

for(;;){

    pthread_mutex_lock( &condition_mutex );
      
         pthread_cond_wait( &condition_cond, &condition_mutex );
            

counter++; sleep(1);
printf("Bom:\n");   
  
pthread_mutex_unlock( &condition_mutex );

}

}

