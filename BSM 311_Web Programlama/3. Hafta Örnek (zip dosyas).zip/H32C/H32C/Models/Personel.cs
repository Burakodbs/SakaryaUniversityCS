﻿namespace H32C.Models
{
    public class Personel
    {
        public int PerSicil { get; set; } 
    }
}
