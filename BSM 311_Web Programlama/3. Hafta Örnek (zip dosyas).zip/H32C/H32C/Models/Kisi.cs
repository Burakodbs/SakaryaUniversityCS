﻿namespace H32C.Models
{
    public class Kisi
    {
        public Ogrenci ogr { get; set; }
        public Personel per { get; set; }
    }
}
