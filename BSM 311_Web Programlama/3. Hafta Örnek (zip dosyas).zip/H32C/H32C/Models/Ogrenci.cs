﻿namespace H32C.Models
{
    public class Ogrenci
    {
        public string OgrAd { get; set; }
        public string OgrSoyad { get; set; }
        public string Ogrno { get; set; }

       // public Personel personel { get; set; }
    }
}
