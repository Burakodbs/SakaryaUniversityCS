// STARTER DOSYA: firebase.js
import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import 'firebase/compat/firestore';

// 1. ADIM: Firebase Console'dan alınan config buraya yapıştırılacak
const firebaseConfig = {
  // Burası derste doldurulacak
};

if (!firebase.apps.length) {
  // 2. ADIM: Başlatma kodu buraya yazılacak
}

export const auth = firebase.auth();
export const firestore = firebase.firestore();