#include <stdio.h>

int main(){
printf("Merhaba Sistem Programlama\n");
return 0;
}
