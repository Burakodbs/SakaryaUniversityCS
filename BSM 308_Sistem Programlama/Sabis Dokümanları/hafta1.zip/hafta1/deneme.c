#include <stdio.h>
int main(){
printf("MerhAbA Linux\n");
return 0;
}
