#include <stdio.h>

int main(){
printf("MerhAbA Sistem progrAmlAmA\n");
return 0;
}
