#include <stdio.h>
#include <stdlib.h>

int main() {
    // Bellek alanı ayırmak için malloc kullanımı
    int *ptr = (int*) malloc(5 * sizeof(int));
   
    // Bellek ayrılamazsa kontrol edin
    if (ptr == NULL) {
        printf("Bellek ayrılamadı.\n");
        exit(0);
    }
   
    // Bellek alanını kullanmak için örnek veri yazın
    for (int i = 0; i < 5; i++) {
        *(ptr + i) = i;
    }
   
    // Bellek alanında veri yazdırmak
    for (int i = 0; i < 5; i++) {
        printf("%d ", *(ptr + i));
    }
   
    // Bellek alanını serbest bırakmak için free kullanımı
    free(ptr);
    ptr = NULL; // İyi bir uygulama için ptr'nin null'a atanması
   
    return 0;
}
