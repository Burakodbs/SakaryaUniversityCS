#include <stdio.h>
typedef long unsigned int LUI;

void swap(int* x, int* y) {
int temp = *x;
*x = *y;
*y = temp;
}

int main() {
int a = 5, b = 10;
int *ap,*bp;
printf("a: %d, b: %d\n", a, b);

ap=&a;
bp=&b;

printf("*a: 0x%lx, *b: 0x%lx\n", (LUI) ap, (LUI) bp);
swap(&a, &b);
printf("a: %d, b: %d\n", *ap, *bp);
printf("*a: 0x%lx, *b: 0x%lx\n", (LUI) ap, (LUI) bp);
return 0;
}
