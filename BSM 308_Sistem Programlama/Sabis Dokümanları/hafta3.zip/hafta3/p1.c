#include <stdlib.h>
#include <stdio.h>

void f1(int *ptr, int len)
{
  int i;
  ptr = (int*) malloc (sizeof(int)*len);
  
  for (i = 0; i < len; i ++)
         ptr[i] = i;
}

int main()
{
	int i, *array;
                
	f1(array, 5);

	for (i = 0; i < 5; i ++)
	printf("got value %d\n", array[i]);

	return 0;
}
