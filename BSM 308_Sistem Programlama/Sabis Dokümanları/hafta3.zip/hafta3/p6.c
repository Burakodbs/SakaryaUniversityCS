#include <stdio.h>

void swap(int* x, int* y) {
    printf("swap içinde x adresi: %p, y adresi: %p\n", (void*)x, (void*)y);
    
    int temp = *x;
    *x = *y;
    *y = temp;
}

int main() {
    int a = 5, b = 10;
    printf("main içinde a adresi: %p, b adresi: %p\n", (void*)&a, (void*)&b);

    swap(&a, &b);

    printf("a: %d, b: %d\n", a, b);
    return 0;
}

