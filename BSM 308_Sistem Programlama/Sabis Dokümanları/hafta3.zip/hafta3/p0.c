#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i;
    char j[14];
    int *ip;
    char *jp;
    printf("ip başlangıç adresi  = 0x%lx\n", (unsigned long)ip); //0 veya çöp deger
    ip = &i;
    jp = j;

    // Bitiş adresleri
    printf("i başlangıç adresi  = 0x%lx\n", (unsigned long)ip);
    printf("i bitiş adresi      = 0x%lx\n", (unsigned long)(ip + 1));

    printf("j başlangıç adresi  = 0x%lx\n", (unsigned long)jp);
    printf("j bitiş adresi      = 0x%lx\n", (unsigned long)(jp + sizeof(j)));

    return 0;
}

