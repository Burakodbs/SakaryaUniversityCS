#include <stdio.h>

void myFunction() {
    static int count = 0;  // Static değişken, 0 ile başlatıldı
    int local_var=0;
    count++; local_var++;
    printf("Count: %d Local: %d \n", count,local_var);
}

int main() {
    myFunction();  // Count: 1
    myFunction();  // Count: 2
    myFunction();  // Count: 3
    return 0;
}
