#include <stdio.h>
char chr ='m';
void fonk_sta(char t) {
// Sadece fonksiyonun ilk çağrısında çalışır.
static char k='a';
if(k<t)
printf("fonk_sta() K değişken değeri: %c\n", k);
k = k + 1;


}
