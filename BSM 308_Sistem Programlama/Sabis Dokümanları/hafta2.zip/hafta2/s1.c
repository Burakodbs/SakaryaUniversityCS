#include <stdio.h>
//gcc s1.c s2.c -o ss
void fonk_sta(char t);

extern char chr;

int main(void)
{
char krktr;

for (krktr='a';krktr<'z';krktr++)
fonk_sta(chr);

return 0;
}


