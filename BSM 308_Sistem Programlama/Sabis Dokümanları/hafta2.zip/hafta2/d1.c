// deneme1.c
#include <stdio.h>

void fonk(void);

int gid = 287; // global int değişken tanımlaması

int main(void) {

printf("deneme1.c gid değişken değeri: %d\n", gid);

fonk(); // deneme2.c dosyasındaki fonk() fonksiyonuna çağrı
return 0;
}
