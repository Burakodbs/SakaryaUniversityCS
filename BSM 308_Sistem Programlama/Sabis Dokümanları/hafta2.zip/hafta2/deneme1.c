// deneme1.c
#include <stdio.h>
void fonk1(void);
void fonk2(void);
static int gid = 21; // Static global int değişken bildirimi
int main(void) {
fonk1();
fonk2();
return 0; }
void fonk1(void)
{ printf("deneme1.c gid değişken değeri: %d\n", gid); }
