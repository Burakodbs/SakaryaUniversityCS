// deneme2.c
#include <stdio.h>
extern int gid; // global int değişken bildirimi
void fonk(void)
{ printf("deneme2.c gid değişken değeri: %d", gid); }
