// deneme2.c
#include <stdio.h>

int gid = 35; // global int değişken bildirimi
void fonk2(void)
{
printf("deneme2.c gid değişken değeri: %d", gid);
}
